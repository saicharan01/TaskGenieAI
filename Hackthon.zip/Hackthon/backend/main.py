import imaplib
import json
import email
from flask import Flask, jsonify,request
import requests
import json
from flask_cors import CORS
from config import ORGANIZATION,PAT,DevOpsURL,HEADERS,ps_model,project_descr2,project_descr1,username,password,mail_server
from requests.auth import HTTPBasicAuth
#from transformers import AutoModelForCausalLM, AutoTokenizer
import torch
from transformers import pipeline


auth = HTTPBasicAuth('', PAT)

global pipe
global classifier
# from flask.blueprints import Blueprint
# from app.models import transaction,rule
app = Flask(__name__)
cors = CORS(app, resources={r"*": {"origins": "http://localhost:3000"}})


@app.route('/')
def home():
    return jsonify({"message": "Welcome to the Flask backend!"})

###---------------------------------------------->Email route<--------------------------------------
@app.route('/email_reciver', methods=['POST'])
def main_email():
    result = fetch_email(username, password, mail_server)
    #print(result)
    title = result['title']
    
    # Extract users from problems_mapped_to_users
    mapped_users_list = result['problems_mapped_to_users']  # This is a list
    if not isinstance(mapped_users_list, list) or len(mapped_users_list) == 0:
        return jsonify({"error": "No problems mapped to users found"}), 400
    
    # Extract the first mapped user's details
    first_problem = mapped_users_list[0]
    user_info = first_problem.get('mapped_users', [])
    if not user_info or len(user_info) == 0:
        return jsonify({"error": "No users mapped to problems"}), 400
    
    # Get the assigned user's name
    user = user_info[0].get('user')  # Assuming you only care about the first user
    if not user:
        return jsonify({"error": "Mapped user information is incomplete"}), 400

    descr = first_problem.get('problem_description', "No description available")
    # print(descr)
    # print(result)
    data = {
        "project": "Anblicks Hackathon - Teamclabtest",
        "sprint": "backlog sprint",
        "title": title,
        "state": "To Do",
        "assigned_to": user,
        "description": descr,
        "priority": 1,
        "tags": "hackathon; testing; task",
        "story_points": 3  # Ensure story points are added
    }

    required_fields = ["title", "state", "assigned_to", "description", "priority", "story_points"]
    for field in required_fields:
        if field not in data:
            return jsonify({"error": f"Missing required field: {field}"}), 400

    url = f'{DevOpsURL}{data["project"]}/_apis/wit/workitems/$task?api-version=5.1'
    iteration_path = data["project"] + "\\" + data["sprint"]
    email = data["assigned_to"] + "@bharathpogula.com"
    
    # Define the JSON-Patch payload
    patch_data = [
        {
            "op": "add",
            "path": "/fields/System.Title",
            "value": data["title"]
        },
        {
            "op": "add",
            "path": "/fields/System.State",
            "value": data["state"]
        },
        {
            "op": "add",
            "path": "/fields/System.AssignedTo",
            "value": email
        },
        {
            "op": "add",
            "path": "/fields/System.Description",
            "value": data["description"]
        },
        {
            "op": "add",
            "path": "/fields/System.IterationPath",
            "value": iteration_path
        },
        {
            "op": "add",
            "path": "/fields/System.AreaPath",
            "value": data["project"]
        },
        {
            "op": "add",
            "path": "/fields/Microsoft.VSTS.Common.Priority",
            "value": data["priority"]
        },
        {
            "op": "add",
            "path": "/fields/Microsoft.VSTS.Scheduling.StoryPoints",
            "value": data["story_points"]
        }
    ]

    # Make the POST request to Azure DevOps API to create the work item
    response = requests.post(url, json=patch_data,
                             headers={'Content-Type': 'application/json-patch+json'},
                             auth=('', PAT))

    if response.status_code in [200, 201]:
        return jsonify({"AIoutput": result, "message": "Work item created successfully", "details": response.json()}), 200
    else:
        return jsonify({
            "error": "Failed to create work item",
            "status_code": response.status_code,
            "details": response.text
        }), response.status_code



def fetch_email(username, password, mail_server, folder="inbox"):
    # Static project description and users with tech stack
    static_data = {
        "project": {
            "title": "Dynamic Filtering Web Application",
            "description": "Build a web application where users can select values from multiple input fields (e.g., dropdowns, checkboxes, date pickers, or text inputs) and dynamically display the filtered output in a table below. The application should be built using React for the frontend and Python (Flask) for the backend.",
            "users_and_roles": [
                {"user": "Charan", "role": "Backend Developer", "tech_stack": ["Python", "Flask"]},
                {"user": "Anil", "role": "Frontend Developer", "tech_stack": ["React", "JavaScript"]}
            ]
        }
    }
 
    # Connect to mail server
    mail = imaplib.IMAP4_SSL(mail_server)
    mail.login(username, password)
    mail.select(folder)
 
    # Search for all emails and get the latest one
    status, email_ids = mail.search(None, 'ALL')
   
    if status == "OK":
        email_ids = email_ids[0].split()
       
        # Fetch the most recent email (last one in the list)
        latest_email_id = email_ids[-1]
       
        status, msg_data = mail.fetch(latest_email_id, "(RFC822)")
       
        if status == "OK":
            raw_email = msg_data[0][1]
            message = email.message_from_bytes(raw_email)
 
            # Parse email details
            subject = message["subject"]
            body = ""
            if message.is_multipart():
                for part in message.walk():
                    if part.get_content_type() == "text/plain":
                        body += part.get_payload(decode=True).decode()
            else:
                body = message.get_payload(decode=True).decode()
 
            # Analyze the problem using the NLP model
            problem_analysis = analyze_with_model(body, static_data["project"]["users_and_roles"])
 
            # Combine project details with the problem mapping
            output = {
                "title": static_data["project"]["title"],
                "description": static_data["project"]["description"],
                "problems_mapped_to_users": [problem_analysis]
            }
           
            mail.logout()
            return output
 
def analyze_with_model(problem_body, users):
    """
    Analyze the email body to determine relevant users based on their expertise.
    """
    labels = [user["role"] for user in users]  # Labels are user roles
    result = classifier(problem_body, labels)
 
    # Get the most relevant labels and map them to users
    mapped_users = []
    for i, label in enumerate(result["labels"]):
        if result["scores"][i] > 0.5:  # Threshold for relevance
            for user in users:
                if user["role"] == label:
                    mapped_users.append({"user": user["user"], "role": user["role"]})
 
    return {
        "problem_description": problem_body.strip(),
        "mapped_users": mapped_users
    }

#--------------------------------------------------------------------------------------------------------
def get_project_id(project_name):
    """Fetch the project ID using the project name."""
    try:
        url = f"{DevOpsURL}/_apis/projects?api-version=7.1"
        response = requests.get(
            url,
            headers={'Content-Type': 'application/json'},
            auth=('', PAT)
        )
        if response.status_code == 200:
            projects = response.json().get('value', [])
            for project in projects:
                if project['name'].lower() == project_name.lower():
                    return project['id']
            return None
        else:
            raise Exception(f"Failed to fetch projects: {response.text}")
    except Exception as e:
        raise Exception(f"Error while fetching project ID: {str(e)}")
    
##------------------------------------------------>Add Comments<----------------------------

@app.route('/add_comment', methods=['POST'])
def add_comment():
    try:
        data = request.json
        required_fields = ["work_item_id", "comment_text","project"]
        
        # Validate input
        for field in required_fields:
            if field not in data:
                return jsonify({"error": f"Missing required field: {field}"}), 400

        # Construct the API URL
        work_item_id = data["work_item_id"]
        project=data["project"]
        url = f"{DevOpsURL}{project}/_apis/wit/workitems/{work_item_id}/comments?api-version=7.1-preview.3"

        # Construct the payload
        payload = {
            "text": data["comment_text"]
        }

        # Add headers
        headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {PAT}"
            }
        # Make the API call
        response = requests.post(url, json=payload, headers=headers)

        # Handle the response
        if response.status_code in [200, 201]:
            return jsonify({"message": "Comment added successfully", "details": response.json()}), 200
        else:
            return jsonify({
                "error": "Failed to add comment",
                "status_code": response.status_code,
                "details": response.text
            }), response.status_code

    except Exception as e:
        return jsonify({"error": "An unexpected error occurred", "details": str(e)}), 500



##-------------------------------------------------->Model Test Cases<-----------------------------

def generate_response(prompt: str):
    #print("prompt---->"+prompt)
    messages = [
    {"role": "user", "content":prompt},
        ]
    #print("Message---->"+messages)
    response = pipe(messages, max_new_tokens=600)
    #print("response completed")
    assistant_content = response[0]['generated_text'][1]['content']

    return assistant_content
@app.route('/generate_pseudocode', methods=['POST'])
def api_generate_pseudocode():
    # # Extract the prompt from the request body
    project=project_descr2
    data = request.get_json()
    project=data.get('project')
    code_language=data.get('language')
    extra_contenct=data.get('content','')
    prompt = data.get('description', '')
    if project=='Anblicks Hackathon - Teamclabtest':
        project_descr=project_descr1
    else:
        project_descr=project_descr2

    prompt_pseudo=f"""
        I want you to act as a programming assistant. I will provide a task name and specify a programming language. Your job is to do the following:

        1) Generate pseudo code for the task, explaining the logic step-by-step in plain language.
        2) Write the actual code sample in the {code_language} programming language.

        Make sure the pseudo code is clear and modular, and the code sample follows best practices.

        Provide output in this format:
            1. Pseudo Code
            2. Code Sample
        Don't hallucinate yourself,here is the project description
        """
    prompt=prompt_pseudo+project_descr+"Here is the problem description"+ prompt+extra_contenct
    if not prompt:
        return jsonify({"error": "Prompt is required"}), 400
    
    # Generate a response based on the prompt
    response = generate_response(prompt)
    
    # Return the generated response as JSON
    return jsonify({"response": response})

# Define an API route to handle requests
@app.route('/generate_test_cases', methods=['POST'])
def api_generate_test_cases():
    data = request.get_json()
    project=data.get('project')
    frame_work=data.get('frame_work')
    extra_contenct=data.get('content','')
    prompt = data.get('description', '')
    if project=='Anblicks Hackathon - Teamclabtest':
        project_descr=project_descr1
    else:
        project_descr=project_descr2

    prompt_test_case = f""""
    I want you to act as a programming assistant. I will provide a task name, a brief description of the functionality, and specify a test framework. Your task is to do the following:
	1.	Understand the task based on the description provided.
	2.	Generate test cases using the {frame_work} test framework to validate the functionality described in the task.
	3.	Ensure the test cases cover:
	•	Valid input scenarios.
	•	Edge cases (boundary conditions or extreme inputs).
	•	Error cases (invalid or missing inputs).
    """
    prompt=prompt_test_case+project_descr+" Here is the problem description "+ prompt+extra_contenct
    if not prompt:
        return jsonify({"error": "Prompt is required"}), 400
    
    # Generate a response based on the prompt
    response = generate_response(prompt)
    
    # Return the generated response as JSON
    return jsonify({"response": response})



## -------------------------------------------->Modified<-----------------------------
@app.route('/getprojects', methods=['GET'])
def get_work_items_for_sprints_with_names():
    try:
        # Step 1: Fetch all projects
        projects_url = DevOpsURL + "/_apis/projects?api-version=6.0"
        response_projects = requests.get(
            projects_url,
            headers={'Content-Type': 'application/json'},
            auth=('', PAT)
        )

        if response_projects.status_code != 200:
            return jsonify({
                "error": "Failed to retrieve projects",
                "status_code": response_projects.status_code,
                "details": response_projects.text
            }), response_projects.status_code

        projects = response_projects.json().get('value', [])
        project_ids = {project['name']: project['id'] for project in projects}

        # Step 2: Fetch all sprints for each project
        all_sprints = {}
        all_work_items = {}

        for project_name, project_id in project_ids.items():
            sprints_url = f"{DevOpsURL}/{project_id}/_apis/work/teamsettings/iterations?api-version=6.0"
            response_sprints = requests.get(
                sprints_url,
                headers={'Content-Type': 'application/json'},
                auth=('', PAT)
            )

            if response_sprints.status_code != 200:
                all_sprints[project_name] = f"Error: {response_sprints.status_code}"
                continue

            sprints = response_sprints.json().get('value', [])
            sprint_ids = {sprint['name']: sprint['id'] for sprint in sprints}
            all_sprints[project_name] = list(sprint_ids.keys())

            # Step 3: Fetch work items for each sprint
            for sprint_name, sprint_id in sprint_ids.items():
                work_items_url = f"{DevOpsURL}/{project_id}/_apis/work/teamsettings/iterations/{sprint_id}/workitems?api-version=6.0"
                response_work_items = requests.get(
                    work_items_url,
                    headers={'Content-Type': 'application/json'},
                    auth=('', PAT)
                )

                if response_work_items.status_code == 200:
                    work_items = response_work_items.json().get('workItemRelations', [])
                    work_item_ids = [item['target']['id'] for item in work_items if 'target' in item]

                    # Fetch work item details (names, descriptions, etc.)
                    work_item_details = []
                    for work_item_id in work_item_ids:
                        item_url = f"{DevOpsURL}/_apis/wit/workitems/{work_item_id}?api-version=6.0"
                        response_item = requests.get(
                            item_url,
                            headers={'Content-Type': 'application/json'},
                            auth=('', PAT)
                        )

                        if response_item.status_code == 200:
                            work_item = response_item.json()
                            fields = work_item.get('fields', {})

                            # Extract details
                            work_item_details.append({
                                "id": work_item_id,
                                "name": fields.get('System.Title', 'Unknown'),
                                "status": fields.get('System.State', 'Unknown'),
                                "story_points": fields.get('Microsoft.VSTS.Scheduling.StoryPoints', 'N/A'),
                                "description": fields.get('System.Description', 'No description available'),
                                "type": fields.get('System.WorkItemType', 'Unknown')
                            })
                        else:
                            work_item_details.append({
                                "error": f"Error: {response_item.status_code}",
                                "work_item_id": work_item_id
                            })

                    # Assign work item details to the project and sprint
                    all_work_items.setdefault(project_name, {})[sprint_name] = work_item_details
                else:
                    all_work_items.setdefault(project_name, {})[sprint_name] = f"Error: {response_work_items.status_code}"

        # Return projects, sprints, and their work items
        return jsonify({
            "projects": list(project_ids.keys()),
            "sprints": all_sprints,
            "work_items": all_work_items
        }), 200

    except Exception as e:
        return jsonify({"error": "An unexpected error occurred", "details": str(e)}), 500
#-----------------------------------------update -------------------------
@app.route('/update_work_item', methods=['PATCH', 'POST'])
def update_work_item():
    try:
        # Get input data from the request body
        data = request.json
        work_item_id = data.get("work_item_id")
        project_name = data.get("project_name")

        updates = data.get("updates")  # Dictionary of fields to update (e.g., {"status": "Done", "name": "New Title"})
        #print(updates)
        
        if not work_item_id or not project_name or not updates:
            return jsonify({"error": "Missing required fields: work_item_id, project_name, or updates"}), 400

        # Construct the URL for the work item update
        url = f"{DevOpsURL}{project_name}/_apis/wit/workitems/{work_item_id}?api-version=6.0"
        HEADERS = {
            'Content-Type': 'application/json-patch+json',  # Correct MIME type for JSON-Patch
        }
        AUTH = ('', PAT)  # Tuple for basic auth: username (empty) and PAT



        # Prepare the JSON-Patch payload for the update
        patch_data = []
        if "status" in updates:
            patch_data.append({
                "op": "add",
                "path": "/fields/System.State",
                "value": updates["status"]
            })
        if "name" in updates:
            patch_data.append({
                "op": "add",
                "path": "/fields/System.Title",
                "value": updates["name"]
            })
        if "description" in updates:
            patch_data.append({
                "op": "add",
                "path": "/fields/System.Description",
                "value": updates["description"]
            })
        if "type" in updates:
            patch_data.append({
                "op": "add",
                "path": "/fields/System.WorkItemType",
                "value": updates["type"]
            })
        if "story_points" in updates:
            patch_data.append({
                "op": "add",
                "path": "/fields/Microsoft.VSTS.Scheduling.StoryPoints",
                "value": updates["story_points"]
            })
        if "sprint" in updates:  # Change the sprint of the work item
            sprint_url = updates["sprint"]  # Sprint URL must be passed (get from iterations API)
            patch_data.append({
                "op": "add",
                "path": "/fields/System.IterationPath",
                "value": sprint_url
            })

        # Make the PATCH request
        response = requests.patch(url, json=patch_data, headers=HEADERS, auth=AUTH)
        #response = requests.patch(url, json=patch_data, headers=HEADERS)

        # Check response and return appropriate message
        if response.status_code in [200, 201]:
            return jsonify({"message": "Work item updated successfully", "details": response.json()}), 200
        else:
            return jsonify({
                "error": "Failed to update work item",
                "status_code": response.status_code,
                "details": response.text
            }), response.status_code

    except Exception as e:
        return jsonify({"error": "An unexpected error occurred", "details": str(e)}), 500
    
##---------------------------------------------create story----------------------------------------


@app.route('/create_work_item', methods=['POST'])
def create_work_item():
    try:
        # Get input data from the request body
        data = request.json
    
        print(data)
        # Validate that all required fields are present
        required_fields = ["title", "state", "assigned_to", "description","priority", "story_points"]
        for field in required_fields:
            if field not in data:
                return jsonify({"error": f"Missing required field: {field}"}), 400
        url = f'{DevOpsURL}{data["project"]}/_apis/wit/workitems/$task?api-version=5.1'
        iteration_path=data["project"]+"\\"+data["sprint"]
        email=data["assigned_to"]+"@bharathpogula.com"
        # Define the JSON-Patch payload
        patch_data = [
            {
                "op": "add",
                "path": "/fields/System.Title",
                "value": data["title"]  # Title of the work item
            },
            {
                "op": "add",
                "path": "/fields/System.State",
                "value": data["state"]  # State of the work item
            },
            {
                "op": "add",
                "path": "/fields/System.AssignedTo",
                "value": email  # Assigned to a user
            },
            {
                "op": "add",
                "path": "/fields/System.Description",
                "value": data["description"]  # Description of the work item
            },
            {
                "op": "add",
                "path": "/fields/System.IterationPath",
                "value": iteration_path  # Iteration path
            },
            {
                "op": "add",
                "path": "/fields/System.AreaPath",
                "value": data["project"] # Area path
            },
            {
                "op": "add",
                "path": "/fields/Microsoft.VSTS.Common.Priority",
                "value": data["priority"]  # Priority level
            },
            {
                "op": "add",
                "path": "/fields/Microsoft.VSTS.Common.Severity",
                "value": "High"  # Severity level
            },
            {
            "op": "add",
            "path": "/fields/Microsoft.VSTS.Scheduling.StoryPoints",
            "value": data["story_points"]  # Story points
            }
            #,
            # {
            #     "op": "add",
            #     "path": "/fields/System.Tags",
            #     "value": data["tags"]  # Tags associated with the work item
            # }
        ]
        
        # Make the POST request to Azure DevOps API to create the work item
        response = requests.post(url, json=patch_data,
                                 headers={'Content-Type': 'application/json-patch+json'},
                                 auth=('', PAT))  # Authentication with Personal Access Token (PAT)

        # Check the response status code
        if response.status_code in [200, 201]:
            return jsonify({"message": "Work item created successfully", "details": response.json()}), 200
        else:
            return jsonify({
                "error": "Failed to create work item",
                "status_code": response.status_code,
                "details": response.text
            }), response.status_code

    except Exception as e:
        return jsonify({"error": "An unexpected error occurred", "details": str(e)}), 500




#----------------------------------------->>Create New Project-------------------------------------
def create_project(project_name, description):
    url = f"{DevOpsURL}/_apis/projects?api-version=6.0"
    payload = {
        "name": project_name,
        "description": description,
        "visibility": "private",
        "capabilities": {
            "versioncontrol": {"sourceControlType": "Git"},
            "processTemplate": {"templateTypeId": "6b724908-ef14-45cf-84f8-768b5384da45"}  # Agile process template
        }
    }
    response = requests.post(url, auth=auth, headers=HEADERS, json=payload)
    if response.status_code == 202:
        return {"message": f"Project '{project_name}' created successfully! It might take some time to initialize."}
    else:
        return {"error": f"Failed to create project: {response.status_code}, {response.text}"}



# def create_board(project_name, board_name):
#     url = f"{DevOpsURL}/{project_name}/_apis/work/boards?api-version=6.0"
#     payload = {
#         "name": board_name,
#         "type": "kanban"
#     }
#     response = requests.post(url, auth=auth, headers=HEADERS, json=payload)
#     if response.status_code == 200:
#         return {"message": f"Board '{board_name}' created successfully!"}
#     else:
#         return {"error": f"Failed to create board: {response.status_code}"}


def add_user_to_project( user_email, project_id):
    url = f"https://vsaex.dev.azure.com/{ORGANIZATION}/_apis/userentitlements?api-version=7.1"

    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {PAT}"
    }

    payload = {
        "accessLevel": {
            "licensingSource": "account",
            "accountLicenseType": "express"
        },
        "extensions": [
            {
                "id": "ms.feed"
            }
        ],
        "user": {
            "principalName": user_email,
            "subjectKind": "user"
        },
        "projectEntitlements": [
            {
                "group": {
                    "groupType": "projectContributor"
                },
                "projectRef": {
                    "id": project_id
                }
            }
        ]
    }

    response = requests.post(url, headers=headers, json=payload)
    if response.status_code == 200:
        return {"message": f"User successfully added to the project."}
    else:
        return {"error": f"Failed to add user to the project: {response.status_code}, {response.text}"}



@app.route('/create_project', methods=['POST'])
def create_project_endpoint():
    try:
        data = request.get_json()

        # Extract project name, description, and users
        project_name = data.get('project_name')
        project_description = data.get('description')
        users = data.get('users', [])  # List of user emails
        #role = data.get('role', 'Contributor')  # Default role is Contributor

        if not project_name or not project_description:
            return jsonify({"error": "Both 'project_name' and 'description' are required"}), 400

        # Create the project
        project_response = create_project(project_name, project_description)

        if "error" in project_response:
            return jsonify(project_response), 400
        # # Create a board for the project
        # board_name = f"Kanban Board for {project_name}"
        # board_response = create_board(project_name, board_name)

        # Add users to the project
        user_responses = []
        for user_email in users:
            project_id="1fd0bd4e-c294-46ec-9f13-fe93af543f11"
            user_response = add_user_to_project(user_email, project_id)
            user_responses.append(user_response)


        

        return jsonify({
            "project_creation": project_response,
            #"board_creation": board_response,
            "user_additions": user_responses
        }), 200

    except Exception as e:
        return jsonify({"error": "An unexpected error occurred", "details": str(e)}), 500

if __name__ == '__main__':
    pipe = pipeline("text-generation", model="Qwen/Qwen2.5-Coder-0.5B-Instruct")
    classifier = pipeline("zero-shot-classification", model="facebook/bart-large-mnli")
    app.run(debug=True)
 
    
