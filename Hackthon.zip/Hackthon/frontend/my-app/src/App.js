import React from 'react';
import {Route, Routes } from 'react-router-dom';
import CreateProject from './components/CreateProject';
import ModifyStory from './components/ModifyStory';
import GenerateTestCase from './components/GenerateTestCase';
import GeneratePseudocode from './components/GeneratePseudocode';
import Navbar from './components/Navbar';
import './App.css'; 
import ProjectHealth from './components/ProjectHealth';
const App = () => {
    
    return (
            <>
                <Navbar />
                <Routes>
                    <Route path="/create-project" element={<CreateProject />} />
                    <Route path="/modify-story" element={<ModifyStory />} />
                    <Route path="/generate-test-case" element={<GenerateTestCase />} />
                    <Route path="/generate-pseudocode" element={<GeneratePseudocode />} />
                    <Route path="/project-health" element={<ProjectHealth />} />
                </Routes>
            </>
    );
};

export default App;







// import React, { useState } from "react";
// import "./App.css";

// function App() {
//   const [showPopup, setShowPopup] = useState(false);
//   const [projects, setProjects] = useState([]);
//   const [selectedProject, setSelectedProject] = useState("");
//   const [formData, setFormData] = useState({
//     projectName: "",
//     description: "",
//     techStack: "",
//     usersRoles: [],
//   });

//   const handleInputChange = (e) => {
//     const { name, value } = e.target;
//     setFormData({ ...formData, [name]: value });
//   };

//   const handleAddUserRole = () => {
//     setFormData({
//       ...formData,
//       usersRoles: [...formData.usersRoles, { email: "", techStack: "" }],
//     });
//   };

//   const handleUserRoleChange = (index, field, value) => {
//     const updatedRoles = formData.usersRoles.map((role, idx) =>
//       idx === index ? { ...role, [field]: value } : role
//     );
//     setFormData({ ...formData, usersRoles: updatedRoles });
//   };

//   const handleCreate = () => {
//     if (formData.projectName.trim() !== "") {
//       setProjects([...projects, formData.projectName]);
//       setSelectedProject(formData.projectName);
//       console.log("Project Created:", formData);
//       setShowPopup(false);
//       setFormData({
//         projectName: "",
//         description: "",
//         techStack: "",
//         usersRoles: [],
//       });
//     } else {
//       alert("Project name cannot be empty!");
//     }
//   };

//   const handleCancel = () => {
//     setShowPopup(false);
//   };

//   return (
//     <div className="container">
//       <header className="header">HEADER</header>
//       <div className="top-section">
//         <div className="input-group">
//           <label htmlFor="projectName">P. Name</label>
//           <div className="dropdown-container">
//             <select
//               id="projectName"
//               value={selectedProject}
//               onChange={(e) => setSelectedProject(e.target.value)}
//             >
//               <option value="" disabled>
//                 Select a project
//               </option>
//               {projects.map((project, index) => (
//                 <option key={index} value={project}>
//                   {project}
//                 </option>
//               ))}
//             </select>
//             <button className="add-button" onClick={() => setShowPopup(true)}>
//               +
//             </button>
//           </div>
//         </div>
//         <div className="input-group">
//           <label htmlFor="sprint">Sprint</label>
//           <input type="text" id="sprint" placeholder="Enter Sprint" />
//         </div>
//       </div>
//       <div className="grid-section">
//         <div className="grid-item">Create New</div>
//         <div className="grid-item">Modify</div>
//         <div className="grid-item">Pseudo Code</div>
//         <div className="grid-item">Test Case</div>
//       </div>

//       {showPopup && (
//         <div className="popup">
//           <div className="popup-content">
//             <h3>Create Project</h3>
//             <div className="input-group">
//               <label htmlFor="popupProjectName">Project Name</label>
//               <input
//                 type="text"
//                 id="popupProjectName"
//                 name="projectName"
//                 value={formData.projectName}
//                 onChange={handleInputChange}
//               />
//             </div>
//             <div className="input-group">
//               <label htmlFor="description">Description</label>
//               <textarea
//                 id="description"
//                 name="description"
//                 value={formData.description}
//                 onChange={handleInputChange}
//               ></textarea>
//             </div>
//             <div className="input-group">
//               <label htmlFor="techStack">Tech Stack</label>
//               <input
//                 type="text"
//                 id="techStack"
//                 name="techStack"
//                 value={formData.techStack}
//                 onChange={handleInputChange}
//               />
//             </div>
//             <div className="input-group">
//               <label>Users & Roles</label>
//               <button onClick={handleAddUserRole} className="add-button">
//                 +
//               </button>
//               {formData.usersRoles.map((role, index) => (
//                 <div key={index} className="user-role">
//                   <input
//                     type="text"
//                     placeholder="Email"
//                     value={role.email}
//                     onChange={(e) =>
//                       handleUserRoleChange(index, "email", e.target.value)
//                     }
//                   />
//                   <input
//                     type="text"
//                     placeholder="Tech Stack"
//                     value={role.techStack}
//                     onChange={(e) =>
//                       handleUserRoleChange(index, "techStack", e.target.value)
//                     }
//                   />
//                 </div>
//               ))}
//             </div>
//             <div className="button-group">
//               <button onClick={handleCreate} className="create-button">
//                 Create
//               </button>
//               <button onClick={handleCancel} className="cancel-button">
//                 Cancel
//               </button>
//             </div>
//           </div>
//         </div>
//       )}
//     </div>
//   );
// }

// export default App;








// import React, { useEffect, useState } from "react";
// import "./App.css";

// function App() {
//   const [projects, setProjects] = useState([]);
//   const [selectedProject, setSelectedProject] = useState("");
//   const [sprint, setSprint] = useState("");
//   const [prompt, setPrompt] = useState("");
//   const [response, setResponse] = useState("");

//   // Fetch projects on component mount
//   useEffect(() => {
//     fetchProjects();
//   }, []);

//   const fetchProjects = async () => {
//     try {
//       const res = await fetch("http://127.0.0.1:5000/getprojects");
//       const data = await res.json();
//       if (data.project_names) {
//         setProjects(data.project_names);
//       } else {
//         console.error("Failed to load projects:", data.error);
//       }
//     } catch (error) {
//       console.error("Error fetching projects:", error);
//     }
//   };

//   const handleGeneratePseudocode = async () => {
//     try {
//       const res = await fetch("http://127.0.0.1:5000/generate_pseudocode", {
//         method: "POST",
//         headers: { "Content-Type": "application/json" },
//         body: JSON.stringify({ prompt }),
//       });
//       const data = await res.json();
//       setResponse(data.response || "No response received.");
//     } catch (error) {
//       console.error("Error generating pseudocode:", error);
//     }
//   };

//   const handleGenerateTestCases = async () => {
//     try {
//       const res = await fetch("http://127.0.0.1:5000/generate_test_cases", {
//         method: "POST",
//         headers: { "Content-Type": "application/json" },
//         body: JSON.stringify({ prompt }),
//       });
//       const data = await res.json();
//       setResponse(data.response || "No response received.");
//     } catch (error) {
//       console.error("Error generating test cases:", error);
//     }
//   };

//   return (
//     <div className="container">
//       <header className="header">Project Management</header>
//       <div className="top-section">
//         <div className="input-group">
//           <label htmlFor="projectName">Project Name</label>
//           <div className="dropdown-container">
//             <select
//               id="projectName"
//               value={selectedProject}
//               onChange={(e) => setSelectedProject(e.target.value)}
//             >
//               <option value="" disabled>
//                 Select a project
//               </option>
//               {projects.map((project, index) => (
//                 <option key={index} value={project}>
//                   {project}
//                 </option>
//               ))}
//             </select>
//           </div>
//         </div>
//         <div className="input-group">
//           <label htmlFor="sprint">Sprint</label>
//           <select
//             id="sprint"
//             value={sprint}
//             onChange={(e) => setSprint(e.target.value)}
//           >
//             <option value="" disabled>
//               Select a Sprint
//             </option>
//             <option value="Sprint 1">Sprint 1</option>
//             <option value="Sprint 2">Sprint 2</option>
//             <option value="Sprint 3">Sprint 3</option>
//           </select>
//         </div>
//       </div>
//       <div className="grid-section">
//         <div
//           className="grid-item"
//           onClick={() => handleGeneratePseudocode()}
//         >
//           Pseudo Code
//         </div>
//         <div
//           className="grid-item"
//           onClick={() => handleGenerateTestCases()}
//         >
//           Test Case
//         </div>
//       </div>
//       <div className="input-section">
//         <textarea
//           placeholder="Enter your prompt here..."
//           value={prompt}
//           onChange={(e) => setPrompt(e.target.value)}
//           rows="4"
//           cols="50"
//         />
//         <div className="response-box">{response}</div>
//       </div>
//     </div>
//   );
// }

// export default App;
