import React, { createContext, useState } from 'react'

export const ProjectContext = createContext();

function ProjectProvider({children}) {
  const [globalProjectName, setGlobalProjectName] = useState("");
  const [globalSprint, setGlobalSprint] = useState("");
  // const [allProjects,setAllProjects] = useState([]);

  return (
    <ProjectContext.Provider value={{globalProjectName,setGlobalProjectName,globalSprint,setGlobalSprint}}>
      {children}
    </ProjectContext.Provider>
  )
}

export default ProjectProvider