import React, { useState } from "react";
import { ApiUrl } from "../services/ApiUrl";
import { useNavigate } from "react-router-dom";

const CreateProject = () => {
  const [projectName, setProjectName] = useState("");
  const [description, setDescription] = useState("");
  const [techstack, setTechstack] = useState("");
  const [usersAndRoles, setUsersAndRoles] = useState([]);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [showPopup, setShowPopup] = useState(false);
  const [editingIndex, setEditingIndex] = useState(null);
  const [boards,setBoards] = useState("");
  const [errors, setErrors] = useState("");
  const navigate = useNavigate();

  const boardOptions = ["Azure DevOps","Atlassian Jira"];

  const handleAddUser = () => {
    if (name && email && techstack) {
      if (editingIndex !== null) {
        // Update the existing user
        const updatedUsers = [...usersAndRoles];
        updatedUsers[editingIndex] = { name, email, techstack };
        setUsersAndRoles(updatedUsers);
        setEditingIndex(null); // Reset the editing index
      } else {
        // Add a new user
        setUsersAndRoles([...usersAndRoles, { name, email, techstack }]);
      }
      setName("");
      setEmail("");
      setTechstack("");
      setShowPopup(false);
    }
  };

  const handleDeleteUser = (index) => {
    const updatedUsers = usersAndRoles.filter((_, i) => i !== index);
    setUsersAndRoles(updatedUsers);
  };

  const handleEditUser = (index) => {
    const user = usersAndRoles[index];
    setName(user.name);
    setEmail(user.email);
    setTechstack(user.techstack);
    setEditingIndex(index);
    setShowPopup(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const result = await ApiUrl.post("create_project", {
        project_name: projectName,
        description,
        techstack,
        users: usersAndRoles,
      });
      setErrors(result.data.project_creation.message);
      setTimeout(() => {
        setErrors("");
      }, 3000);
      console.log(result.data.project_creation.message);
      setProjectName("");
      setDescription("");
      setTechstack("");
      setUsersAndRoles("");
    } catch (error) {
      console.error("Error creating project:", error);
    }
  };

  return (
    <div>
      <div className="max-w-4xl mx-auto mt-2 rounded-lg shadow-lg p-6 bg-gradient-to-br from-sky-950 to-violet-500 mb-2">
        <h1 className="text-3xl font-semibold text-center text-white mb-6">
          Create Project
        </h1>

        <div className="space-y-4">
          <label
            htmlFor="boards"
            className="text-white p-2 text-xl font-medium"
          >
            Boards
          </label>
          <select
            id="boards"
            value={boards}
            onChange={(e) => setBoards(e.target.value)}
            className="inline w-full mt-2 p-2 border border-gray-300 rounded-md"
            required
          >
            <option value="" disabled>
              Select a Boards
            </option>
            {boardOptions.map((board) => (
              <option key={board} value={board}>
                {board}
              </option>
            ))}
          </select>
          <div>
            <label
              htmlFor="projectName"
              className="block text-xl font-medium text-white"
            >
              Project Name
            </label>
            <input
              type="text"
              id="projectName"
              placeholder="Enter project name"
              value={projectName}
              onChange={(e) => setProjectName(e.target.value)}
              className="mt-1 p-2 block w-full border-gray-900 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
              required
            />
          </div>

          <div>
            <label
              htmlFor="description"
              className="block text-xl font-medium text-white"
            >
              Description
            </label>
            <textarea
              id="description"
              placeholder="Enter description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="mt-1 px-2 py-4 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
              required
            />
          </div>

          <div>
            <label
              htmlFor="techstack"
              className="block text-xl font-medium text-white"
            >
              Tech Stack
            </label>
            <input
              type="text"
              id="techstack"
              placeholder="Enter tech stack"
              value={techstack}
              onChange={(e) => setTechstack(e.target.value)}
              className="mt-1 p-2 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
            />
          </div>
        </div>

        <div className="mt-6">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-xl text-white font-medium">Users & Roles</h3>
            <button
              className="bg-blue-500 text-black font-medium text-xl px-4 py-2 rounded-md hover:bg-blue-600"
              onClick={() => setShowPopup(true)}
            >
              + Add User
            </button>
          </div>

          <ul className="space-y-2">
            {usersAndRoles.map((user, index) => (
              <li
                key={index}
                className="flex justify-between items-center bg-gray-100 p-4 rounded-md shadow-sm"
              >
                <span className="text-black">
                  {user.name} - {user.email} - {user.techstack}
                </span>
                <div className="space-x-2">
                  <button
                    className="bg-green-300 text-black font-medium px-6 py-2 rounded-md hover:bg-green-500"
                    onClick={() => handleEditUser(index)}
                  >
                    Edit
                  </button>
                  <button
                    className="bg-red-500 text-white font-medium px-6 py-2 rounded-md hover:bg-red-900"
                    onClick={() => handleDeleteUser(index)}
                  >
                    Delete
                  </button>
                </div>
              </li>
            ))}
          </ul>
        </div>

        <div className="mt-6 flex space-x-4">
          <button
            className="bg-green-500 text-black font-medium px-6 py-2 rounded-md hover:bg-green-600"
            onClick={handleSubmit}
          >
            Create Project
          </button>
          <button
            className="bg-red-500 text-white font-medium px-6 py-2 rounded-md hover:bg-red-900"
            onClick={() => navigate("/")}
          >
            Cancel
          </button>
        </div>
      </div>
      {errors && (
        <div className="bg-black p-2 rounded-lg">
          <p className="text-green-500 text-xl font-medium">{errors}</p>
        </div>
      )}
      {showPopup && (
        <div className="fixed inset-0 flex items-center justify-center bg-gray-900 bg-opacity-50">
          <div className="bg-gradient-to-br from-pink-950 to-violet-950 p-6 rounded-lg shadow-lg max-w-sm w-full">
            <h3 className="text-xl text-center text-white font-medium mb-4">
              {editingIndex !== null ? "Edit User" : "Add User"}
            </h3>

            <div className="space-y-4">
              <div>
                <label
                  htmlFor="name"
                  className="block text-xl font-medium text-white"
                >
                  Name
                </label>
                <input
                  type="text"
                  id="name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Enter name"
                  className="mt-1 p-2 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                />
              </div>

              <div>
                <label
                  htmlFor="email"
                  className="block text-xl font-medium text-white"
                >
                  Email
                </label>
                <input
                  type="email"
                  id="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter email"
                  className="mt-1 p-2 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                />
              </div>

              <div>
                <label
                  htmlFor="popupTechstack"
                  className="block text-xl font-medium text-white"
                >
                  Tech Stack
                </label>
                <input
                  type="text"
                  id="popupTechstack"
                  value={techstack}
                  onChange={(e) => setTechstack(e.target.value)}
                  placeholder="Enter tech stack"
                  className="mt-1 p-2 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                />
              </div>
            </div>

            <div className="mt-6 flex space-x-4">
              <button
                className="bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600"
                onClick={handleAddUser}
              >
                {editingIndex !== null ? "Save" : "Add"}
              </button>
              <button
                className="bg-red-500 text-white px-4 py-2 rounded-md hover:bg-red-900"
                onClick={() => setShowPopup(false)}
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CreateProject;
