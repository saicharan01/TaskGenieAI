import React, { useState } from 'react';
import { ComposedChart, XAxis, YAxis, Tooltip, Legend, CartesianGrid, Area, Bar, Line } from "recharts";

function ProjectHealth() {

  const data = [
    { name: "A", uv: 4000, pv: 2400, amt: 2400 },
    { name: "B", uv: 3000, pv: 1398, amt: 2210 },
    { name: "C", uv: 2000, pv: 5000, amt: 2290 },
    { name: "D", uv: 2780, pv: 3908, amt: 2000 },
    { name: "E", uv: 1890, pv: 4800, amt: 2181 },
    { name: "F", uv: 2390, pv: 3800, amt: 2500 },
    { name: "G", uv: 3490, pv: 4300, amt: 2100 }
  ];

  return (<div>
    <div className='bg-black opacity-80 z-10'>
    <div className="flex justify-center items-center space-x-4 p-4">
        <div className="text-4xl font-bold text-gray-400 text-center">TaskGenieAI</div>

        <div className="flex justify-center items-center gap-4">
          {/* Box 1 */}
          <div className="w-7 h-7 bg-green-500"></div>

          {/* Box 2 */}
          <div className="w-8 h-8 bg-green-600"></div>

          {/* Box 4 */}
          <div className="w-9 h-9 bg-green-900"></div>
        </div>
      </div>
    </div>
    <div className="relative w-full h-[500px] flex justify-center items-center">
      {/* Overlay with transparency */}
      <div className="absolute inset-0 bg-black opacity-80 z-10"></div>

      {/* Composed Chart */}
      <ComposedChart width={730} height={500} data={data} className="z-0">
        <XAxis dataKey="name" />
        <YAxis />
        <Tooltip />
        <Legend />
        <CartesianGrid stroke="#f5f5f5" />
        <Area type="monotone" dataKey="amt" fill="#8884d8" stroke="#8884d8" />
        <Bar dataKey="pv" barSize={20} fill="#413ea0" />
        <Line type="monotone" dataKey="uv" stroke="#ff7300" />
      </ComposedChart>

      {/* Launching Soon text */}
      <div className="absolute inset-0 flex items-center justify-center shadow-2xl z-20 text-6xl font-bold bg-gradient-to-r from-orange-500 via-purple-200 to-orange-500 bg-clip-text text-transparent">
        Launching Soon....
      </div>
    </div>
    </div>
  );
}

export default ProjectHealth;
