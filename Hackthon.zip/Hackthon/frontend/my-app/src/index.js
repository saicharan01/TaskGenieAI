import React from "react";
import ReactDOM from "react-dom";
import App from "./App";
import "./App.css";
import "./index.css";
import { BrowserRouter } from "react-router-dom";
import ProjectProvider from "./context/ProjectProvider";

ReactDOM.render(
  <React.StrictMode>
    <BrowserRouter>
      <ProjectProvider>
        <App />
      </ProjectProvider>
    </BrowserRouter>
  </React.StrictMode>,
  document.getElementById("root")
);
