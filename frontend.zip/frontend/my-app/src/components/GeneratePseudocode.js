import React, { useState, useEffect, useContext } from "react";
import { ApiUrl } from "../services/ApiUrl";
import { useNavigate } from "react-router-dom";
import { ProjectContext } from "../context/ProjectProvider";

const GeneratePseudocode = () => {
  const [storyName, setStoryName] = useState("");
  const [language, setLanguage] = useState("");
  const [description, setDescription] = useState("");
  const [result, setResult] = useState("");
  const [storyNames, setStoryNames] = useState([]);
  const [loading, setLoading] = useState(false);
  const [storyId, setStoryId] = useState();
  const [content, setContent] = useState("");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [errors, setErrors] = useState("");
  const navigate = useNavigate();
  const { globalSprint, globalProjectName } = useContext(ProjectContext);
  const languages = ["Python", "C", "Java", "JavaScript", "Ruby", "Go","React","Angular"];

  // Fetch story names dynamically
  useEffect(() => {
    async function fetchStories() {
      try {
        const response = await ApiUrl.get("getprojects");
        console.log(globalProjectName, globalSprint);
        const responseWorkItems = response.data.work_items;
        console.log(responseWorkItems[globalProjectName][globalSprint]);
        setStoryNames(responseWorkItems[globalProjectName][globalSprint]);
      } catch (error) {
        console.error("Error fetching story names:", error);
      }
    }
    fetchStories();
  }, []);

  const handleGenerate = async () => {
    try {
      setLoading(true);
      const response = await ApiUrl.post("generate_pseudocode", {
        project: globalProjectName,
        language: language,
        content: content,
        description: description,
      });
      let cleanedResult = response.data.response.replace(/\#/g, ""); // Remove all occurrences of '*'
      console.log(cleanedResult);

      setResult(cleanedResult);
      setIsModalOpen(true);
    } catch (error) {
      console.error("Error generating test cases:", error);
      setResult("Failed to generate test cases. Please try again.");
      setIsModalOpen(true); // Open modal even on failure
    } finally {
      setLoading(false);
    }
  };

  const handleCancel = () => {
    setStoryName("");
    setLanguage("");
    setDescription("");
    setResult("");
    navigate("/");
  };

  const closeModal = () => {
    setIsModalOpen(false);
  };

  const handleApprove = async () => {
    try {
      const response = await ApiUrl.post("add_comment", {
        work_item_id: storyId,
        comment_text: result,
        project: globalProjectName,
      });
      console.log(response.data);
      setIsModalOpen(false);
      setErrors("Comment Succesfully Added...");
      setTimeout(() => {
        setErrors("");
      }, 3000);
    } catch (error) {
      console.log(error);
    } finally {
      setStoryName("");
      setLanguage("");
      setContent("");
      setDescription("");
      setResult("");
    }
  };

  return (
    <div className="container mx-auto mt-6 max-w-4xl p-6 bg-gradient-to-br from-sky-950 to-violet-500 shadow-md rounded-md">
      <h1 className="text-2xl font-bold text-white mb-6 text-center">
        Generate Pseudocode
      </h1>

      {/* Dropdowns */}
      <div className="flex flex-col md:flex-row gap-4 mb-6">
        {/* Story Name Dropdown */}
        <div className="w-full">
          <label
            htmlFor="storyName"
            className="block text-sm font-medium text-white mb-2"
          >
            Select Story Name:
          </label>
          <select
            id="storyName"
            className="block w-full p-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
            value={storyName}
            onChange={(e) => {
              const selectedStory = storyNames.find(
                (story) => story.name === e.target.value
              );
              console.log("selectedStory", selectedStory);
              setStoryName(selectedStory.name);
              setDescription(selectedStory.description);
              setStoryId(selectedStory.id);
            }}
          >
            <option value="" disabled>
              Select Story
            </option>
            {storyNames.map((story, index) => (
              <option key={index} value={story.name} className="text-black">
                {story.name}
              </option>
            ))}
          </select>
        </div>

        {/* Language Dropdown */}
        <div className="w-full">
          <label
            htmlFor="language"
            className="block text-sm font-medium text-white mb-2"
          >
            Select Language:
          </label>
          <select
            id="language"
            className="block w-full p-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
            value={language}
            onChange={(e) => setLanguage(e.target.value)}
          >
            <option value="" disabled>
              Select Language
            </option>
            {languages.map((lang, index) => (
              <option key={index} value={lang}>
                {lang}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Description */}
      {description && (
        <div className="bg-orange-200 rounded-lg p-2">
          <p className="text-black p-2 inline text-lg font-medium ">
            Description :
          </p>
          <span className="text-black">{description}</span>
        </div>
      )}

      <div className="mb-6 p-3">
        <label
          htmlFor="content"
          className="block text-sm font-medium text-white mb-2"
        >
          Add More Content (Optional):
        </label>
        <textarea
          id="content"
          className="block w-full p-3 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
          placeholder="Enter content..."
          value={content}
          onChange={(e) => setContent(e.target.value)}
        ></textarea>
      </div>

      {/* Buttons */}
      <div className="flex justify-end gap-4 mb-6">
        <button
          onClick={handleGenerate}
          disabled={loading} // Disable button during loading
          className={`px-6 py-2 font-medium rounded-md shadow text-white ${
            loading
              ? "bg-gray-500 cursor-not-allowed"
              : "bg-violet-800 hover:bg-blue-950"
          }`}
        >
          {loading ? "Generating..." : "Generate"}
        </button>
        <button
          onClick={handleCancel}
          className="px-6 py-2 bg-red-700 text-white font-medium rounded-md shadow hover:bg-red-950 focus:outline-none focus:ring-2 focus:ring-gray-300 focus:ring-offset-2"
        >
          Cancel
        </button>
      </div>

      {errors && (
        <div className="bg-black p-2 rounded-lg">
          <p className="text-green-500 text-xl font-medium">{errors}</p>
        </div>
      )}

      {/* Result Section */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 flex justify-center items-center z-50">
          <div className="bg-white p-6 rounded-lg shadow-xl max-w-4xl w-full max-h-[75vh] overflow-auto">
            <h3 className="text-lg font-semibold text-gray-800 mb-4 text-center">
              Generated Test Case
            </h3>
            <div className="overflow-y-auto max-h-[60vh]">
              <pre className="text-sm text-gray-700 whitespace-pre-wrap">
                {result}
              </pre>
            </div>
            <div className="mt-4 flex justify-end gap-4">
              <button
                onClick={handleApprove}
                className="px-6 py-2 bg-green-700 text-white rounded-md hover:bg-gray-900"
              >
                Approve
              </button>
              <button
                onClick={closeModal}
                className="px-6 py-2 bg-gray-700 text-white rounded-md hover:bg-gray-900"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default GeneratePseudocode;
