import React, { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import Anblicks from "../assets/anblicks.jpg";

function Navbar() {
  const navigate = useNavigate();
  const location = useLocation();
  const [typedText, setTypedText] = useState("");
  const textToType = "Welcome to TaskGenieAI App! Let's innovate together.";

  useEffect(() => {
    if (location.pathname === "/") {
      let index = 0;
      const typingInterval = setInterval(() => {
        setTypedText((prev) => prev + textToType[index]);
        index++;
        if (index === textToType.length) {
          clearInterval(typingInterval); // Stop typing animation when complete
        }
      }, 100); // Adjust typing speed here (milliseconds per character)

      return () => clearInterval(typingInterval);
    } else {
      setTypedText(""); // Clear typed text if not on "/"
    }
  }, [location.pathname]);

  return (
    <div className="flex flex-col bg-gradient-to-br from-pink-950 to-violet-950 text-white">
      <header className="flex items-center justify-between px-6 py-4   shadow-md">
        <h1 className="text-6xl font-bold bg-gradient-to-r from-orange-100 via-purple-200 to-orange-300 bg-clip-text text-transparent">TaskGenieAI</h1>
        <img src={Anblicks} alt="Anblicks" className="rounded-lg"/>
      </header>
      <nav className="flex flex-wrap justify-center gap-4 p-10">
        <button
          className="p-4 text-2xl font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-500 focus:ring-2 focus:ring-blue-400 focus:ring-offset-2"
          onClick={() => navigate("/create-project")}
        >
          Create Project
        </button>
        <button
          className="p-4 text-2xl font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-500 focus:ring-2 focus:ring-blue-400 focus:ring-offset-2"
          onClick={() => navigate("/modify-story")}
        >
          Create/Modify Story
        </button>
        <button
          className="p-4 text-2xl font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-500 focus:ring-2 focus:ring-blue-400 focus:ring-offset-2"
          onClick={() => navigate("/generate-test-case")}
        >
          Generate Test Case
        </button>
        <button
          className="p-4 text-2xl font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-500 focus:ring-2 focus:ring-blue-400 focus:ring-offset-2"
          onClick={() => navigate("/generate-pseudocode")}
        >
          Generate Pseudocode
        </button>
        <button
          className="p-4 text-2xl font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-500 focus:ring-2 focus:ring-blue-400 focus:ring-offset-2"
          onClick={() => navigate("/project-health")}
        >
          Project Health
        </button>
      </nav>
      {location.pathname === "/" && (
        <div className="flex-grow p-64 flex items-center justify-center">
          <h2 className="text-3xl font-semibold text-center">{typedText}</h2>
        </div>
      )}
    </div>
  );
}

export default Navbar;
