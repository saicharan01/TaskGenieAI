import React, { useState, useEffect, useContext } from "react";
import { ApiUrl } from "../services/ApiUrl";
import { useNavigate } from "react-router-dom";
import { ProjectContext } from "../context/ProjectProvider";

const ModifyStory = () => {
  const [projects, setProjects] = useState([]);
  const [sprints, setSprints] = useState([]);
  const [fetchedSprints, setFetchedSprints] = useState([]);
  const [projectName, setProjectName] = useState("");
  const [sprint, setSprint] = useState("");
  const [inputSelection, setInputSelection] = useState([]);
  const [outputSelection, setOutputSelection] = useState([]);
  const [pseudoCodeLanguage, setPseudoCodeLanguage] = useState("");
  const [testFramework, setTestFramework] = useState("");
  const [title, setTitle] = useState("");
  const [storyPoints, setStoryPoints] = useState(1);
  const [format, setFormat] = useState("");
  const [status, setStatus] = useState(""); // Added state for status dropdown
  const [type, setType] = useState("");
  const [workItems, setWorkItems] = useState();
  const [stories, setStories] = useState();
  const [loading, setLoading] = useState(true);
  const [priority, setPriority] = useState(1);
  const [description, setDescription] = useState("");
  const [assigned_to, setAssignTo] = useState("");
  const [errors, setErrors] = useState("");
  const navigate = useNavigate();
  const { setGlobalProjectName, setGlobalSprint } = useContext(ProjectContext);
  const [isPopupOpen, setIsPopupOpen] = useState(false);
  const [copyIsPopupOpen, setCopyIsPopupOpen] = useState(false);
  const [selectedStory, setSelectedStory] = useState(null);
  const [selectedFrom, setSelectedFrom] = useState("");
  const [selectedTo, setSelectedTo] = useState("");

  const inputOptions = [
    "Title",
    "Status",
    "Story Points",
    "Priority",
    "Description",
    "Type",
  ];
  const outputOptions = [
    "Pseudocode",
    // "Acceptance Criteria",
    "Test Case",
    // "Title",
    // "Description",
    // "Story Points",
  ];
  const pseudoCodeLanguages = ["Python", "JavaScript", "Java", "C++"];
  const testFrameworks = ["JUnit", "PyTest", "Mocha", "RSpec"];
  const statusOptions = ["To Do", "Doing", "Done"];
  const typeOptions = ["Task", "Epic", "Issue"];
  const assignToOptions = ["Charan", "Anil", "Bharath", "Lalitha"];
  const fromCopyOptions = ["Atlassian Jira", "Azure DevOps"];

  useEffect(() => {
    const fetchProjectsAndSprints = async () => {
      try {
        const projectResponse = await ApiUrl.get("getprojects");
        console.log(projectResponse.data);

        setProjects(projectResponse.data.projects);
        setFetchedSprints(projectResponse.data.sprints);
        setWorkItems(projectResponse.data.work_items);
        setLoading(false);
      } catch (error) {
        console.error("Error fetching projects or sprints:", error);
        setLoading(false);
      }
    };

    fetchProjectsAndSprints();
  }, []);

  // Handle changes for multi-select
  const handleInputSelectionChange = (e) => {
    const { value, checked } = e.target;
    setInputSelection((prev) =>
      checked ? [...prev, value] : prev.filter((item) => item !== value)
    );
  };

  const handleOutputSelectionChange = (e) => {
    const { value, checked } = e.target;
    setOutputSelection((prev) =>
      checked ? [...prev, value] : prev.filter((item) => item !== value)
    );
  };

  const handleProjectName = (e) => {
    const selectedProject = e.target.value;
    setGlobalProjectName(selectedProject);
    setProjectName(e.target.value);
    if (fetchedSprints && fetchedSprints[selectedProject]) {
      console.log(fetchedSprints[selectedProject]);
      setSprints(fetchedSprints[selectedProject]);
    }
  };

  const handleSprint = (e) => {
    const selectedSprint = e.target.value;
    setGlobalSprint(selectedSprint);
    setSprint(selectedSprint);
    if (workItems && workItems[projectName][selectedSprint]) {
      console.log(workItems[projectName][selectedSprint]);
      setStories(workItems[projectName][selectedSprint]);
    }
  };

  const handleCreateStory = async () => {
    // "title", "state", "assigned_to", "description","priority","story_points" project  sprint
    try {
      const response = await ApiUrl.post("create_work_item", {
        title,
        state: status,
        assigned_to,
        description,
        priority,
        story_points: storyPoints,
        project: projectName,
        sprint,
      });
      console.log(response.data.message);
      setErrors(response.data.message);
      setTitle("");
      setStatus("");
      setAssignTo("");
      setDescription("");
      setStoryPoints(1);
      setProjectName("");
      setSprint("");
      setPriority(1);
      setStories("");
      setTimeout(() => {
        setErrors("");
      }, 3000);
    } catch (error) {
      console.log(error);
    }
  };

  const handleEditClick = (story) => {
    setSelectedStory({ ...story }); // Set the selected story
    setIsPopupOpen(true); // Open the popup
  };

  const handleCopyStory = () => {
    setCopyIsPopupOpen(true);
  };

  const handleCloseCopyStory = () => {
    setCopyIsPopupOpen(false);
  };

  const handleClosePopup = () => {
    setIsPopupOpen(false); // Close the popup
    setSelectedStory(null); // Reset the selected story
  };
  const handleCopySave = (selectedFrom, selectedTo) => {
    console.log(selectedFrom, selectedTo);
  };

  const handleSaveChanges = async () => {
    // Logic to save the changes (API call or state update)
    try {
      console.log("Updated story:", selectedStory);
      const response = await ApiUrl.post("update_work_item", {
        work_item_id: selectedStory.id,
        project_name: projectName,
        updates: {
          name: selectedStory.name,
          description: selectedStory.description,
          status: selectedStory.status,
          type: selectedStory.type,
          story_points: selectedStory.story_points,
        },
      });
      console.log(response.data);
      setErrors(response.data.message);
      setTimeout(() => {
        setErrors("");
      }, 3000);
    } catch (error) {
      console.log(error);
    }

    // Close the popup after saving
    setIsPopupOpen(false);
    setProjectName("");
    setSprint("");
    setStories("");
  };

  return (
    <>
      {loading ? (
        <div className="container mx-auto p-10 m-4 bg-gradient-to-br from-sky-950 to-violet-500 rounded-lg shadow-md">
          <div className="flex space-x-2 items-center justify-center">
            <div className="w-6 h-6 bg-blue-300 rounded-full animate-bounce"></div>
            <div className="w-6 h-6 bg-green-300 rounded-full animate-bounce delay-200"></div>
            <div className="w-6 h-6 bg-red-300 rounded-full animate-bounce delay-400"></div>
            <p className="text-white text-xl font-medium text-center">
              Good things take time—loading now!
            </p>
          </div>
        </div>
      ) : (
        <div className="container mx-auto p-10 m-4 bg-gradient-to-br from-sky-950 to-violet-500 rounded-lg shadow-md">
          <header className="pb-4 pt-1 text-center text-white text-3xl font-medium">
            Create Story
          </header>
          {/* Header Section */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
            <div className="space-y-2">
              <label
                htmlFor="projectName"
                className="block text-white text-2xl font-medium"
              >
                Project Name:
              </label>
              <select
                id="projectName"
                value={projectName}
                onChange={handleProjectName}
                className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring focus:ring-blue-200"
              >
                <option value="" disabled>
                  Select Project
                </option>
                {projects.map((project, index) => (
                  <option key={index} value={project}>
                    {project}
                  </option>
                ))}
              </select>
            </div>

            <div className="space-y-2">
              <label
                htmlFor="sprint"
                className="block text-white text-2xl font-medium"
              >
                Sprint:
              </label>
              <select
                id="sprint"
                value={sprint}
                onChange={handleSprint}
                className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring focus:ring-blue-200"
              >
                <option value="" disabled>
                  Select Sprint
                </option>
                {sprints &&
                  sprints.map((sprint, index) => (
                    <option key={index} value={sprint}>
                      {sprint}
                    </option>
                  ))}
              </select>
            </div>
          </div>
          <div className="flex items-center justify-center">
            <button
              className="text-black text-xl bg-orange-500 px-6 py-3 rounded-lg font-medium"
              onClick={handleCopyStory}
            >
              Copy Story
            </button>
          </div>
          {/* Input and Output Section */}
          <div className="flex items-center justify-center">
            <div className="space-y-2">
              <label
                htmlFor="inputSelection"
                className="block text-white text-center text-2xl font-medium p-4"
              >
                Input:
              </label>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <div className="form-group mb-4">
                  <label
                    htmlFor="title"
                    className="text-white p-2 text-xl font-medium"
                  >
                    Title
                  </label>
                  <input
                    type="text"
                    id="title"
                    placeholder="Enter Title"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    className="inline w-full mt-2 p-2 border border-gray-300 rounded-md"
                    required
                  />
                </div>

                <div className="form-group mb-4">
                  <label
                    htmlFor="description"
                    className="text-white p-2 text-xl font-medium"
                  >
                    Description
                  </label>
                  <textarea
                    id="description"
                    placeholder="Enter Description"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    className="inline w-full mt-2 p-2 border border-gray-300 rounded-md"
                    required
                  />
                </div>

                <div className="form-group mb-4">
                  <label
                    htmlFor="storyPoints"
                    className="text-white p-2 text-xl font-medium"
                  >
                    Story Points
                  </label>
                  <input
                    type="number"
                    placeholder="Enter Story Points"
                    id="storyPoints"
                    value={storyPoints}
                    onChange={(e) => setStoryPoints(Number(e.target.value))}
                    className="inline w-full mt-2 p-2 border border-gray-300 rounded-md"
                    required
                  />
                </div>

                <div className="form-group mb-4">
                  <label
                    htmlFor="priority"
                    className="text-white p-2 text-xl font-medium"
                  >
                    Priority
                  </label>
                  <input
                    type="number"
                    id="priority"
                    value={priority}
                    onChange={(e) => setPriority(Number(e.target.value))}
                    min="1"
                    max="5"
                    className="inline w-full mt-2 p-2 border border-gray-300 rounded-md"
                    required
                  />
                </div>

                <div className="form-group mb-4">
                  <label
                    htmlFor="status"
                    className="text-white p-2 text-xl font-medium"
                  >
                    Status
                  </label>
                  <select
                    id="status"
                    value={status}
                    onChange={(e) => setStatus(e.target.value)}
                    className="inline w-full mt-2 p-2 border border-gray-300 rounded-md"
                    required
                  >
                    <option value="" disabled>
                      Select a Status
                    </option>
                    {statusOptions.map((status) => (
                      <option key={status} value={status}>
                        {status}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="form-group mb-4">
                  <label
                    htmlFor="assigned_to"
                    className="text-white p-2 text-xl font-medium"
                  >
                    Assign To
                  </label>
                  <select
                    id="assigned_to"
                    value={assigned_to}
                    onChange={(e) => setAssignTo(e.target.value)}
                    className="inline w-full mt-2 p-2 border border-gray-300 rounded-md"
                    required
                  >
                    <option value="" disabled>
                      Select a Assignee
                    </option>
                    {assignToOptions.map((assignee) => (
                      <option key={assignee} value={assignee}>
                        {assignee}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="form-group mb-4">
                  <label
                    htmlFor="type"
                    className="text-white p-2 text-xl font-medium"
                  >
                    Type
                  </label>
                  <select
                    id="type"
                    value={type}
                    onChange={(e) => setType(e.target.value)}
                    className="inline w-full mt-2 p-2 border border-gray-300 rounded-md"
                    required
                  >
                    <option value="" disabled>
                      Select a type
                    </option>
                    {typeOptions.map((type) => (
                      <option key={type} value={type}>
                        {type}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="flex justify-center items-center gap-x-4 p-4 mt-4">
                  <button className="py-2 px-4 bg-orange-800 text-white font-medium rounded-lg mr-2">
                    Auto Sprint Planning
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Submit Button */}
          <div className="flex justify-center items-center gap-x-4 p-4 mt-4">
            <button
              className="px-4 py-2 bg-green-500 text-black font-bold rounded-md shadow-md hover:bg-green-900 focus:outline-none focus:ring focus:ring-blue-300"
              onClick={handleCreateStory}
            >
              Create
            </button>
            <button
              className="px-4 py-2 bg-red-600 text-white font-medium rounded-md shadow-md hover:bg-red-900 focus:outline-none focus:ring focus:ring-gray-200"
              onClick={() => navigate("/")}
            >
              Cancel
            </button>
          </div>
          {errors && (
            <div className="text-green-400 text-xl font-medium text-center bg-black p-4 rounded-lg">
              {errors}
            </div>
          )}
        </div>
      )}
      {stories && (
        <>
          <div className="bg-gradient-to-br from-sky-950 to-violet-500 p-6">
            <h1 className="text-3xl font-bold text-center mb-4 text-white">
              Story Board
            </h1>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {stories.map((story, index) => (
                <div
                  key={index}
                  className="border rounded-md shadow-lg p-2 m-2 bg-white"
                >
                  <h2 className="text-xl text-center font-bold mb-2">
                    {story.name}
                  </h2>
                  <p className="pl-2">
                    <strong>Status:</strong> {story.status}
                  </p>
                  <p className="pl-2">
                    <strong>Story Points:</strong> {story.story_points}
                  </p>
                  <p className="pl-2">
                    <strong>Type:</strong> {story.type}
                  </p>
                  {/* <p className="pl-2">
                    <strong>Acceptance Criteria:</strong>{" "}
                    {story.acceptance_criteria}
                  </p> */}
                  <p className="pl-2">
                    <strong>Description:</strong> {story.description}
                  </p>
                  <div className="flex items-center justify-end">
                    <button
                      className="py-2 px-4 mr-2 bg-orange-600 text-white font-medium rounded-lg"
                      onClick={() => handleEditClick(story)}
                    >
                      Edit
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </>
      )}

      {isPopupOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center">
          <div className="bg-gradient-to-br from-sky-950 to-violet-500 rounded-lg shadow-lg p-6 w-1/3">
            <h2 className="text-xl font-bold mb-4 text-white text-center">
              Edit Story
            </h2>
            <div className="mb-4">
              <label className="block font-medium text-white">Name:</label>
              <input
                type="text"
                className="w-full border rounded-lg p-2"
                value={selectedStory.name}
                onChange={(e) =>
                  setSelectedStory({ ...selectedStory, name: e.target.value })
                }
              />
            </div>
            <div className="form-group mb-4">
              <label htmlFor="status" className="p-2 font-medium text-white">
                Status
              </label>
              <select
                id="status"
                value={selectedStory.status || ""} // Pre-select current status
                onChange={(e) =>
                  setSelectedStory({ ...selectedStory, status: e.target.value })
                }
                className="inline w-full mt-2 p-2 border border-gray-300 rounded-md"
                required
              >
                <option value="" disabled>
                  Select a Status
                </option>
                {statusOptions.map((status) => (
                  <option key={status} value={status}>
                    {status}
                  </option>
                ))}
              </select>
            </div>
            <div className="mb-4">
              <label className="block font-medium text-white">
                Story Points:
              </label>
              <input
                type="number"
                className="w-full border rounded-lg p-2"
                value={selectedStory.story_points}
                onChange={(e) =>
                  setSelectedStory({
                    ...selectedStory,
                    story_points: e.target.value,
                  })
                }
              />
            </div>
            <div className="mb-4">
              <label className="block font-medium text-white">
                Description:
              </label>
              <textarea
                className="w-full border rounded-lg p-6"
                value={selectedStory.description || ""}
                onChange={(e) =>
                  setSelectedStory({
                    ...selectedStory,
                    description: e.target.value,
                  })
                }
              />
            </div>
            <div className="mb-4">
              <label htmlFor="type" className="block font-medium text-white">
                Type
              </label>
              <select
                id="type"
                value={selectedStory.type || ""} // Pre-select current type
                onChange={(e) =>
                  setSelectedStory({ ...selectedStory, type: e.target.value })
                }
                className="inline w-full mt-2 p-2 border border-gray-300 rounded-md"
                required
              >
                <option value="" disabled>
                  Select a type
                </option>
                {typeOptions.map((type) => (
                  <option key={type} value={type}>
                    {type}
                  </option>
                ))}
              </select>
            </div>
            <div className="flex justify-end">
              <button
                className="py-2 px-4 bg-red-800 text-white font-medium rounded-lg mr-2"
                onClick={handleClosePopup}
              >
                Cancel
              </button>
              <button
                className="py-2 px-4 bg-blue-900 text-white font-medium rounded-lg"
                onClick={handleSaveChanges}
              >
                Save
              </button>
            </div>
          </div>
        </div>
      )}

      {copyIsPopupOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center">
          <div className="bg-gradient-to-br from-sky-950 to-violet-500 rounded-lg shadow-lg p-6 w-1/3">
            <h2 className="text-xl font-bold mb-4 text-white text-center">
              Copy Story
            </h2>

            {/* From Dropdown */}
            <div className="form-group mb-4">
              <label htmlFor="from" className="p-2 font-medium text-white">
                From
              </label>
              <select
                id="from"
                value={selectedFrom}
                onChange={(e) => {
                  setSelectedFrom(e.target.value);
                  setSelectedTo(""); // Reset To dropdown when From changes
                }}
                className="inline w-full mt-2 p-2 border border-gray-300 rounded-md"
                required
              >
                <option value="" disabled>
                  Select a Source
                </option>
                {fromCopyOptions.map((option) => (
                  <option key={option} value={option}>
                    {option}
                  </option>
                ))}
              </select>
            </div>

            {/* To Dropdown */}
            <div className="form-group mb-4">
              <label htmlFor="to" className="p-2 font-medium text-white">
                To
              </label>
              <select
                id="to"
                value={selectedTo}
                onChange={(e) => setSelectedTo(e.target.value)}
                className="inline w-full mt-2 p-2 border border-gray-300 rounded-md"
                required
              >
                <option value="" disabled>
                  Select a Destination
                </option>
                {fromCopyOptions
                  .filter((option) => option !== selectedFrom) // Exclude selectedFrom option
                  .map((option) => (
                    <option key={option} value={option}>
                      {option}
                    </option>
                  ))}
              </select>
            </div>

            <div className="flex justify-end">
              <button
                className="py-2 px-4 bg-red-700 text-white font-medium rounded-lg mr-2"
                onClick={handleCloseCopyStory}
              >
                Cancel
              </button>
              <button
                className="py-2 px-4 bg-blue-900 text-white font-medium rounded-lg"
                onClick={() => handleCopySave(selectedFrom, selectedTo)}
              >
                Save
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default ModifyStory;

{
  /* <div className="space-y-2">
              <label
                htmlFor="outputSelection"
                className="block text-white text-2xl font-medium"
              >
                Output:
              </label>
              {outputOptions.map((output, index) => (
                <div key={index} className="flex items-center">
                  <input
                    type="checkbox"
                    id={output}
                    value={output}
                    onChange={handleOutputSelectionChange}
                    checked={outputSelection.includes(output)}
                    disabled={inputSelection.includes(output)} // Disable checkbox if selected in Input
                    className="mr-2 transform scale-150"
                  />
                  <label htmlFor={output} className="text-white text-xl">
                    {output}
                  </label>

                  
                  {output === "Pseudocode" &&
                    outputSelection.includes("Pseudocode") && (
                      <div className="ml-4">
                        <label
                          htmlFor="pseudoCodeLanguage"
                          className="text-white"
                        >
                          Pseudocode Language:
                        </label>
                        <select
                          id="pseudoCodeLanguage"
                          value={pseudoCodeLanguage}
                          onChange={(e) =>
                            setPseudoCodeLanguage(e.target.value)
                          }
                          className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring focus:ring-blue-200"
                        >
                          <option value="" disabled>
                            Select Language
                          </option>
                          {pseudoCodeLanguages.map((language, index) => (
                            <option key={index} value={language}>
                              {language}
                            </option>
                          ))}
                        </select>
                      </div>
                    )}

                  {output === "Test Case" &&
                    outputSelection.includes("Test Case") && (
                      <div className="ml-4">
                        <label htmlFor="testFramework" className="text-white">
                          Test Framework:
                        </label>
                        <select
                          id="testFramework"
                          value={testFramework}
                          onChange={(e) => setTestFramework(e.target.value)}
                          className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring focus:ring-blue-200"
                        >
                          <option value="" disabled>
                            Select Framework
                          </option>
                          {testFrameworks.map((framework, index) => (
                            <option key={index} value={framework}>
                              {framework}
                            </option>
                          ))}
                        </select>
                      </div>
                    )}
                </div>
              ))}
            </div> */
}

{
  /* Format Selection */
}
{
  /* <div className="mb-6">
            <label
              htmlFor="format"
              className="block text-white text-2xl p-2 font-medium"
            >
              Format:
            </label>
            <select
              id="format"
              value={format}
              onChange={(e) => setFormat(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring focus:ring-blue-200"
            >
              <option value="" disabled>
                Select Format
              </option>
              <option value="Only Points">Only Points</option>
              <option value="Parent-Child">Parent-Child</option>
            </select>
          </div> */
}
